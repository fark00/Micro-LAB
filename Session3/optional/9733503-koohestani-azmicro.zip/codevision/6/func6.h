#ifndef __func6_INCLUDE__
#define __func6_INCLUDE__

void func6(void);

#endif