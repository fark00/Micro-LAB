#ifndef__func2_INCLUDE__
#define__func2_INCLUDE__

/*
*
*
*
*/
void func2(void);

#endif