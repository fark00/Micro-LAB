#ifndef__func3_INCLUDE__
#define__func3_INCLUDE__

/*
*
*
*
*/
void func3(void);

#endif