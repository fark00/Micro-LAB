# ifndef__func4_INCLUDE__
#define__func4_INCLUDE__

void func4(void);

#endif