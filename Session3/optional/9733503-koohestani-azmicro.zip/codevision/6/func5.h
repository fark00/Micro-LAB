#ifndef __func5_INCLUDE__
#define __func5_INCLUDE__

void func5();

#endif