#include <header.h>

void func6(void){

    func1();
    func2();
    func3();   
    func5();         
    func4();   
    return;

}