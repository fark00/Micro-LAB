#include <mega16.h>
#include <alcd.h>
#include <func1.h>
#include <func2.h>
#include <func3.h>
#include <func4.h>
#include <func5.h>
#include <func6.h>
#include <init.h>
#include <keypad.h>
#include <delay.h>
#include <string.h>

extern unsigned char key_pad[];